import React from 'react';
import {StyleSheet} from 'react-native';
import Constants from 'expo-constants';

const style = StyleSheet.create({
  body:{
    flex: 1
  },

 container:{
   border: 'double',
   borderWidth: 3,
   borderRadius: 25,
   marginTop: 60,
   alignItems: 'center',
   backgroundColor: '#1ab3ff'
 },

 input:{
   border: 'outset',
   marginTop: 10,
   width: 160,
   height: 30,
   borderRadius: 15,
   backgroundColor: 'white',
   color: 'blue'
 },

 titulo:{
   fontWeight: 'bold',
   fontSize: 36,
   marginBottom: 30,
 },

 subtitulo:{
   marginTop: 20,
   marginLeft: 5,
   fontSize:20,
   fontWeight: 'bold'

 },

 button:{
   width: 120,
   height: 45,
   marginTop: 35,
   backgroundColor: 'blue',
   border: 'groove',
   borderRadius: 20,
   alignItems: 'center'
 },

 textoButton:{
   fontWeight: 'bold',
   marginTop: 4,
   fontSize: 20,
   color: 'white'
 },

 botoes:{
   flexDirection: 'row',
   flexWrap: 'wrap',
   margin: 40
 }

});

export default style;