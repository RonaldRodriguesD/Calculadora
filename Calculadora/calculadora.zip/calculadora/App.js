import * as React from 'react';
import { Text, View, StyleSheet, TextInput, TouchableHighlight } from 'react-native';
import Constants from 'expo-constants';
import Styles from './components/Styles';

const somar = () => {
  setValorResultado(valor1 + valor2);
}

export default function App() {
  const [valor1, setValor1] = React.useState(0);
  const [valor2, setValor2] = React.useState(0);
  const [valorResultado, setValorResultado] = React.useState(0);
  const somar = () => {
    setValorResultado(parseInt(valor1) + parseInt (valor2));
  }
  const subtrair = () => {
    setValorResultado(parseInt(valor1) - parseInt (valor2));
  }
  const multiplicar = () => {
    setValorResultado(parseInt(valor1) * parseInt (valor2));
  }
  const dividir = () => {
    setValorResultado(parseInt(valor1) / parseInt (valor2));
  }
  const limpar = () => {
    setValor1(0);
    setValor2(0);
    setValorResultado(0);
  }




  return (
    <View style={Styles.body}>
      <View style={Styles.container}>
        <Text style={Styles.titulo}>Calculadora</Text>
        <Text style={Styles.subtitulo}>Primeiro valor</Text>
        <TextInput 
          style={Styles.input}
          placeholder = 'valor 1'
          value = {valor1} 
          onChangeText = {(num)=>{setValor1(num)}}
          keyboardType = 'numeric'
        />
        <Text style={Styles.subtitulo}>Segundo valor</Text>
        <TextInput
        style={Styles.input}
        placeholder = 'valor 2'
        value = {valor2}
        onChangeText = {(num)=>{setValor2(num)}}
        keyboardType = 'numeric'
        />
        <Text style={Styles.subtitulo}>Resultado</Text>
        <TextInput
        style={Styles.input}
        value = {String(valorResultado)}
        onChangeText = {(num)=>{setValorResultado(num)}}
        keyboardType = 'numeric'
        />
        <View style={Styles.botoes}>
          <TouchableHighlight
          activeOpacity = {0.1}
          underlayColor= 'black'
          onPress = {somar}
          style={Styles.button}
          >
            <Text style={Styles.textoButton}>Somar</Text>
          </TouchableHighlight>
          <TouchableHighlight
          activeOpacity = {0.1}
          underlayColor= 'black'
          onPress = {subtrair}
          style={Styles.button}
          >
            <Text style={Styles.textoButton}>Subtrair</Text>
          </TouchableHighlight>
          <TouchableHighlight
          activeOpacity = {0.1}
          underlayColor= 'black'
          onPress = {multiplicar}
          style={Styles.button}
          >
            <Text style={Styles.textoButton}>Multiplicar</Text>
          </TouchableHighlight>
          <TouchableHighlight
          activeOpacity = {0.1}
          underlayColor= 'black'
          onPress = {dividir}
          style={Styles.button}
          >
            <Text style={Styles.textoButton}>Dividir</Text>
          </TouchableHighlight>
        </View>
        <TouchableHighlight
          activeOpacity = {0.1}
          underlayColor= 'black'
          onPress = {limpar}
          style={Styles.button}
          >
            <Text style={Styles.textoButton}>Limpar</Text>
          </TouchableHighlight>
      </View>
    </View>
  );
}


